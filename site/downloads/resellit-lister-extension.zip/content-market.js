(() => {
  // extension/src/lib/filler.js
  var norm = (s) => String(s ?? "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").trim();
  var CONTROLS = {
    text: 'input:not([type=hidden]):not([type=file]):not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]),[contenteditable="true"]',
    textarea: 'textarea,[contenteditable="true"]',
    files: "input[type=file]",
    select: 'select,[aria-haspopup="listbox"],[role=combobox]:not(input)',
    path: 'select,[aria-haspopup="listbox"],[role=combobox]:not(input)',
    combo: "input[role=combobox],input[aria-autocomplete],input[type=text],input:not([type])",
    toggle: "input[type=checkbox],[role=switch],[role=checkbox]",
    chips: "[aria-pressed],[role=checkbox],input[type=checkbox]"
  };
  var SUBMIT_WORDS = /* @__PURE__ */ new Set(["list", "list it", "list this item", "list item", "publish", "post", "post now", "submit", "upload", "sell", "next"]);
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var winOf = (el) => el.ownerDocument.defaultView;
  function waitFor(fn, { timeout = 4e3, interval = 40 } = {}) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      const tick = () => {
        let v;
        try {
          v = fn();
        } catch {
          v = null;
        }
        if (v) return resolve(v);
        if (Date.now() - t0 > timeout) return reject(new Error("timeout"));
        setTimeout(tick, interval);
      };
      tick();
    });
  }
  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    if (el.type === "file") return true;
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return false;
    const cs = winOf(el).getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none";
  }
  function controlNear(doc, labelEl, kind) {
    const sel = CONTROLS[kind] || CONTROLS.text;
    if (labelEl.htmlFor) {
      const c = doc.getElementById(labelEl.htmlFor);
      if (c) return c;
    }
    if (labelEl.id) {
      const c = doc.querySelector(`[aria-labelledby~="${CSS.escape(labelEl.id)}"]`);
      if (c) return kind === "chips" ? c : c.matches(sel) ? c : c.querySelector(sel) || c;
    }
    const nested = labelEl.querySelector(sel);
    if (nested) return kind === "chips" ? labelEl : nested;
    let p = labelEl.parentElement;
    for (let i = 0; i < 4 && p; i++, p = p.parentElement) {
      const found = [...p.querySelectorAll(sel)].filter((c) => c !== labelEl && !labelEl.contains(c));
      if (kind === "chips" && found.length >= 2) return p;
      if (kind !== "chips" && found.length) return found[0];
    }
    return null;
  }
  function labelElements(doc, labels) {
    const wanted = labels.map(norm);
    const out = [];
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const t = norm(n.nodeValue);
      if (!t || t.length > 40) continue;
      const el = n.parentElement;
      if (!el || el.closest("script,style,[role=listbox],[data-resellit-ui]")) continue;
      const own = norm(el.textContent).replace(/\s*(required|optional)$/, "");
      if (wanted.includes(t) || wanted.includes(own)) out.push(el);
    }
    return out.sort((a, b) => (/(LABEL|LEGEND)/.test(b.tagName) ? 1 : 0) - (/(LABEL|LEGEND)/.test(a.tagName) ? 1 : 0));
  }
  function resolveField(doc, field) {
    for (const s of field.selectors || []) {
      try {
        const el = doc.querySelector(s);
        if (el) return { el, strategy: "selector" };
      } catch {
      }
    }
    const labels = field.label || [];
    const wanted = labels.map(norm);
    if (field.kind !== "chips") {
      for (const el of doc.querySelectorAll("[aria-label]")) {
        const al = norm(el.getAttribute("aria-label"));
        if (wanted.includes(al) || /:/.test(el.getAttribute("aria-label")) && wanted.some((w) => w && al.startsWith(w + " "))) {
          const sel = CONTROLS[field.kind] || CONTROLS.text;
          const c = el.matches(sel) ? el : el.querySelector(sel);
          if (c) return { el: c, strategy: "aria-label" };
        }
      }
    }
    for (const lab of labelElements(doc, labels)) {
      const c = controlNear(doc, lab, field.kind);
      if (c) return { el: c, strategy: "label" };
    }
    if (field.kind === "text" || field.kind === "textarea" || field.kind === "combo") {
      for (const el of doc.querySelectorAll("[placeholder]")) {
        const p = norm(el.getAttribute("placeholder"));
        if (wanted.some((w) => w && p.startsWith(w))) return { el, strategy: "placeholder" };
      }
    }
    return null;
  }
  function healthCheck(doc, adapter) {
    const rows = adapter.fields.map((f) => {
      const r = resolveField(doc, f);
      return { key: f.key, label: f.label[0], found: !!r, strategy: r?.strategy || null, required: !!f.required };
    });
    return { ok: rows.every((r) => r.found || !r.required), rows, found: rows.filter((r) => r.found).length, total: rows.length };
  }
  function guardNotSubmit(el, adapter) {
    const isButtonish = el.matches("button,input[type=submit],input[type=button],a,[role=button]");
    if (!isButtonish) return;
    for (const s of adapter?.never || []) {
      try {
        if (el.matches(s)) throw new Error(`Refused to click a publish control (${s})`);
      } catch (e) {
        if (e.message.startsWith("Refused")) throw e;
      }
    }
    if (SUBMIT_WORDS.has(norm(el.textContent || el.value))) throw new Error(`Refused to click "${(el.textContent || el.value).trim()}": the seller presses it`);
  }
  function bringIntoView(el) {
    const w = winOf(el);
    const r = el.getBoundingClientRect();
    if (r.top < 60 || r.bottom > w.innerHeight - 60) w.scrollBy(0, r.top - w.innerHeight / 2 + r.height / 2);
  }
  function realClick(el, adapter) {
    guardNotSubmit(el, adapter);
    const w = winOf(el);
    const o = { bubbles: true, cancelable: true, composed: true, view: w };
    bringIntoView(el);
    el.dispatchEvent(new w.PointerEvent("pointerdown", o));
    el.dispatchEvent(new w.MouseEvent("mousedown", o));
    el.dispatchEvent(new w.PointerEvent("pointerup", o));
    el.dispatchEvent(new w.MouseEvent("mouseup", o));
    el.click();
  }
  function setText(el, value) {
    const w = winOf(el);
    bringIntoView(el);
    el.focus?.({ preventScroll: true });
    if (el.isContentEditable) {
      el.textContent = value;
    } else {
      const proto = el.tagName === "TEXTAREA" ? w.HTMLTextAreaElement.prototype : w.HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
    }
    el.dispatchEvent(new w.InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: value }));
    el.dispatchEvent(new w.Event("change", { bubbles: true }));
    el.blur?.();
    return (el.isContentEditable ? el.textContent : el.value) === value;
  }
  function setFiles(input, photos) {
    const w = winOf(input);
    const dt = new w.DataTransfer();
    for (const p of photos) dt.items.add(new w.File([p.bytes], p.name, { type: p.type || "image/jpeg", lastModified: Date.now() }));
    input.files = dt.files;
    input.dispatchEvent(new w.Event("input", { bubbles: true }));
    input.dispatchEvent(new w.Event("change", { bubbles: true }));
    return input.files.length;
  }
  function optionMatch(options, wanted) {
    const w = norm(wanted);
    const list = options.map((o) => ({ o, t: norm(o.getAttribute("data-value") || o.textContent) }));
    return (list.find((x) => x.t === w) || list.find((x) => x.t.startsWith(w + " ")) || list.find((x) => x.t.startsWith(w)) || list.find((x) => x.t.includes(w)))?.o || null;
  }
  function visibleOptions(doc, trigger) {
    const id = trigger?.getAttribute?.("aria-controls");
    const scope = id && doc.getElementById(id) || doc;
    return [...scope.querySelectorAll("[role=option]")].filter(isVisible);
  }
  async function pickNative(select, wanted) {
    const opt = optionMatch([...select.options], wanted);
    if (!opt) return false;
    const w = winOf(select);
    Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype, "value").set.call(select, opt.value);
    select.dispatchEvent(new w.Event("input", { bubbles: true }));
    select.dispatchEvent(new w.Event("change", { bubbles: true }));
    return true;
  }
  async function pickPath(doc, trigger, path, adapter) {
    if (trigger.tagName === "SELECT") {
      if (path.length > 1) {
        const groups = [...trigger.querySelectorAll("optgroup")].filter((g) => norm(g.label) === norm(path[0]));
        const opt = groups.length ? optionMatch(groups.flatMap((g) => [...g.querySelectorAll("option")]), path[path.length - 1]) : null;
        if (opt) {
          const w = winOf(trigger);
          Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype, "value").set.call(trigger, opt.value);
          trigger.dispatchEvent(new w.Event("input", { bubbles: true }));
          trigger.dispatchEvent(new w.Event("change", { bubbles: true }));
          return true;
        }
      }
      return pickNative(trigger, path[path.length - 1]);
    }
    realClick(trigger, adapter);
    for (const step of path) {
      const opt = await waitFor(() => optionMatch(visibleOptions(doc, trigger), step), { timeout: 2500 }).catch(() => null);
      if (!opt) {
        doc.dispatchEvent(new (winOf(trigger)).KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        return false;
      }
      realClick(opt, adapter);
      await sleep(30);
    }
    return true;
  }
  async function pickCombo(doc, input, wanted, adapter) {
    setText(input, wanted);
    input.focus?.({ preventScroll: true });
    const opt = await waitFor(() => optionMatch(visibleOptions(doc, input), wanted), { timeout: 1500 }).catch(() => null);
    if (!opt) return "typed";
    realClick(opt, adapter);
    return "picked";
  }
  function setToggle(el, on, adapter) {
    const cur = el.type === "checkbox" ? el.checked : el.getAttribute("aria-checked") === "true" || el.getAttribute("aria-pressed") === "true";
    if (cur !== !!on) realClick(el, adapter);
    return true;
  }
  function setChips(group, values, max, adapter) {
    const buttons = [...group.querySelectorAll(CONTROLS.chips)];
    let n = 0;
    for (const v of values.slice(0, max || values.length)) {
      const b = optionMatch(buttons, v);
      if (!b) continue;
      const on = b.getAttribute("aria-pressed") === "true" || b.getAttribute("aria-checked") === "true" || b.checked;
      if (!on) realClick(b, adapter);
      n++;
    }
    return n;
  }
  function valueFor(field, payload) {
    const v = payload[field.from];
    if (field.kind === "toggle") return !!v;
    if (Array.isArray(v)) return v.length ? v : null;
    if (v === null || v === void 0 || v === "") return null;
    return field.kind === "text" || field.kind === "textarea" || field.kind === "combo" || field.kind === "select" ? String(v) : v;
  }
  async function fillListing(doc, adapter, payload, { photos = [], onStep = () => {
  }, pace = 0 } = {}) {
    const t0 = Date.now();
    if (adapter.ready) await waitFor(() => resolveField(doc, adapter.ready), { timeout: 8e3 }).catch(() => null);
    const rows = [];
    for (const field of adapter.fields) {
      const value = field.kind === "files" ? photos.length ? photos : null : valueFor(field, payload);
      const row = { key: field.key, label: field.label[0], required: !!field.required, status: "skipped", strategy: null, detail: "" };
      rows.push(row);
      if (value === null || field.kind === "toggle" && value === false && !field.writeFalse) {
        onStep(row);
        continue;
      }
      const hit = resolveField(doc, field);
      if (!hit) {
        row.status = "not_found";
        onStep(row);
        continue;
      }
      row.strategy = hit.strategy;
      const el = hit.el;
      try {
        switch (field.kind) {
          case "text":
          case "textarea":
            row.status = setText(el, value) ? "filled" : "failed";
            break;
          case "files": {
            const n = setFiles(el, value);
            const shown = field.countSelector ? await waitFor(() => doc.querySelectorAll(field.countSelector).length >= n && doc.querySelectorAll(field.countSelector).length, { timeout: 3e3 }).catch(() => doc.querySelectorAll(field.countSelector).length) : n;
            row.status = shown >= value.length ? "filled" : "partial";
            row.detail = `${shown} of ${value.length} photos attached in order`;
            break;
          }
          case "select":
            row.status = el.tagName === "SELECT" ? await pickNative(el, value) ? "filled" : "failed" : await pickPath(doc, el, [value], adapter) ? "filled" : "failed";
            break;
          case "path":
            row.status = await pickPath(doc, el, value, adapter) ? "filled" : "failed";
            row.detail = value.join(" \u203A ");
            break;
          case "combo": {
            const r = await pickCombo(doc, el, value, adapter);
            row.status = r === "picked" ? "filled" : "partial";
            row.detail = r === "typed" ? "typed; not in the marketplace list" : "";
            break;
          }
          case "toggle":
            row.status = setToggle(el, value, adapter) ? "filled" : "failed";
            break;
          case "chips": {
            const n = setChips(el, value, field.max, adapter);
            row.status = n === Math.min(value.length, field.max || 99) ? "filled" : n ? "partial" : "failed";
            row.detail = value.slice(0, field.max || 99).join(", ");
            break;
          }
          default:
            row.status = "failed";
            row.detail = `unknown kind ${field.kind}`;
        }
      } catch (e) {
        row.status = "failed";
        row.detail = e.message;
      }
      row.el = el;
      onStep(row);
      if (pace) await sleep(pace);
    }
    const counted = rows.filter((r) => r.status !== "skipped");
    const filled = counted.filter((r) => r.status === "filled").length;
    const missing = counted.filter((r) => r.status !== "filled").map((r) => r.label);
    const blocking = counted.filter((r) => r.required && r.status !== "filled").map((r) => r.label);
    return {
      total: counted.length,
      filled,
      missing,
      blocking,
      status: blocking.length ? "needs_attention" : missing.length ? "review_with_notes" : "ready",
      ms: Date.now() - t0,
      fields: rows.map(({ el, ...r }) => r)
    };
  }

  // extension/src/lib/listing-id.js
  var PATTERNS = {
    poshmark: /\/listing\/(?:[^/?#]*-)?([0-9a-f]{24})(?=[/?#]|$)/i,
    ebay: /\/itm\/(?:[^/?#]*\/)?(\d{9,15})(?=[/?#]|$)/,
    mercari: /\/item\/(m\d{6,15})(?=[/?#]|$)/i,
    depop: /\/products\/([a-z0-9][a-z0-9-]{2,120})(?=\/?[?#]?|$)/i,
    vinted: /\/items\/(\d{5,15})(?:-[^/?#]*)?(?=[/?#]|$)/,
    facebook: /\/marketplace\/item\/(\d{6,20})(?=[/?#]|$)/
  };
  function parseListingUrl(market, href) {
    let u;
    try {
      u = new URL(href);
    } catch {
      return null;
    }
    const re = PATTERNS[market];
    if (!re) return null;
    const m = u.pathname.match(re);
    if (!m) return null;
    return { market, listingId: m[1], url: u.origin + u.pathname };
  }

  // extension/src/ui/panel.js
  var CSS2 = `
:host{all:initial}
.c{position:fixed;right:12px;top:12px;z-index:2147483647;width:300px;max-width:calc(100vw - 32px);font:13px/1.45 system-ui,sans-serif;color:#1c1b19;background:#fffdf8;border:1px solid #d9d2c3;border-radius:12px;box-shadow:0 14px 40px rgba(28,27,25,.22);overflow:hidden}
.h{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#1c1b19;color:#fffdf8;font-weight:700}
.h i{width:10px;height:10px;border-radius:50%;background:#f59e0b}
.h i.ok{background:#22c55e}.h i.bad{background:#ef4444}
.b{padding:10px 12px}
.s{margin:0 0 6px}
ul{list-style:none;margin:6px 0 0;padding:0;max-height:180px;overflow:auto}
li{display:flex;justify-content:space-between;gap:8px;padding:2px 0;border-bottom:1px dashed #e7e1d4}
li b{font-weight:600}
.filled{color:#15803d}.partial,.not_found,.failed{color:#b42318}.skipped{color:#6b6459}
.cta{margin:8px 0 0;padding:8px;border-radius:8px;background:#fef3c7;font-weight:600}
.c.mini{width:auto}.c.mini .b{display:none}.c.mini .h{cursor:pointer}
.tog{all:unset;cursor:pointer;color:#fffdf8;opacity:.85;padding:0 4px;font-size:12px}
button{all:unset;cursor:pointer;color:#fffdf8;opacity:.8;padding:0 4px}
.tog{margin-left:auto}
`;
  var ICON = { filled: "\u2713", partial: "!", not_found: "?", failed: "\u2717", skipped: "\u2013" };
  var Panel = class {
    constructor(title, doc = document) {
      this.doc = doc;
      const host = doc.createElement("div");
      host.setAttribute("data-resellit-ui", "");
      const root = host.attachShadow({ mode: "closed" });
      root.innerHTML = `<style>${CSS2}</style><div class="c" role="status" aria-live="polite"><div class="h"><i></i><span class="t"></span><button class="tog" aria-expanded="true" aria-label="Collapse ReSellit panel">\u25B4</button><button class="x" aria-label="Hide ReSellit panel">\u2715</button></div><div class="b"><p class="s"></p><ul></ul></div></div>`;
      this.$ = (s) => root.querySelector(s);
      this.title = title;
      this.$(".t").textContent = "ReSellit \xB7 " + title;
      this.$(".x").addEventListener("click", () => host.remove());
      this.$(".tog").addEventListener("click", () => this.mini(!this.$(".c").classList.contains("mini")));
      (doc.body || doc.documentElement).append(host);
      this.host = host;
    }
    mini(on) {
      this.$(".c").classList.toggle("mini", on);
      this.$(".tog").setAttribute("aria-expanded", String(!on));
      this.$(".tog").textContent = on ? "\u25BE" : "\u25B4";
      if (on && this.summary) this.$(".t").textContent = "ReSellit \xB7 " + this.summary;
      if (!on) this.$(".t").textContent = "ReSellit \xB7 " + this.title;
    }
    status(text) {
      this.$(".s").textContent = text;
    }
    step(row) {
      const li = this.doc.createElement("li");
      li.innerHTML = `<b></b><span class="${row.status}"></span>`;
      li.firstChild.textContent = row.label;
      li.lastChild.textContent = `${ICON[row.status] || ""} ${row.status === "filled" ? row.detail || "filled" : row.status.replace("_", " ")}`;
      this.$("ul").append(li);
    }
    done(r) {
      this.$(".h i").className = r.status === "ready" ? "ok" : "bad";
      this.status(`Filled ${r.filled} of ${r.total} fields in ${(r.ms / 1e3).toFixed(1)} s.`);
      const p = this.doc.createElement("p");
      p.className = "cta";
      p.textContent = r.blocking.length ? `Needs you: ${r.blocking.join(", ")}. Fill ${r.blocking.length > 1 ? "them" : "it"} in, then review and list.` : "Review everything, then press the marketplace\u2019s own button to list. ReSellit records the link automatically.";
      this.$(".b").append(p);
      this.summary = r.blocking.length ? `${r.filled}/${r.total} filled \xB7 needs you` : `${r.filled}/${r.total} filled \xB7 your turn: review and list`;
      setTimeout(() => this.mini(true), 2500);
    }
    error(msg) {
      this.$(".h i").className = "bad";
      this.status("Stopped: " + msg);
    }
  };

  // extension/src/content-market.js
  var ask = (msg) => chrome.runtime.sendMessage(msg);
  var MARKET = (() => {
    if (location.hostname.endsWith("poshmark.com")) return "poshmark";
    return location.pathname.match(/^\/market\/([a-z]+)\//)?.[1] || null;
  })();
  function b64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  async function getJob() {
    const t0 = Date.now();
    while (Date.now() - t0 < 5e3) {
      const job = await ask({ type: "GET_JOB" }).catch(() => null);
      if (job && !job.error) return job;
      await new Promise((r) => setTimeout(r, 150));
    }
    return null;
  }
  async function runFill(job) {
    const panel = new Panel(job.adapter ? `Filling the ${job.market === "poshmark" ? "Poshmark" : job.market} form` : "ReSellit");
    try {
      panel.status(`Attaching ${job.photos.length} photos\u2026`);
      const photos = [];
      for (let i = 0; i < job.photos.length; i++) {
        const p = await ask({ type: "GET_PHOTO", index: i });
        if (!p || p.error) throw new Error(p?.error || `photo ${i + 1} unavailable`);
        photos.push({ name: p.name, type: p.type, bytes: b64ToBytes(p.b64) });
        panel.status(`Photos ${i + 1}/${job.photos.length}`);
      }
      const health = healthCheck(document, job.adapter);
      const report = await fillListing(document, job.adapter, job.payload, {
        photos,
        onStep: (row) => panel.step(row)
      });
      report.health = { found: health.found, total: health.total, adapterVersion: job.adapter.version };
      report.warnings = job.warnings || [];
      await ask({ type: "FILLED", report });
      panel.done(report);
    } catch (e) {
      panel.error(e.message);
      await ask({ type: "FILL_FAILED", error: e.message });
    }
  }
  async function runReconcile(job) {
    const panel = new Panel("Checking your listings");
    const adapter = job.adapter;
    await waitFor(() => document.querySelector(adapter.reconcile.item) || document.querySelector("main"), { timeout: 8e3 }).catch(() => null);
    await new Promise((r) => setTimeout(r, 300));
    const items = [...document.querySelectorAll(adapter.reconcile.item)].map((el) => ({
      id: el.getAttribute(adapter.reconcile.id),
      sku: el.getAttribute(adapter.reconcile.sku),
      status: el.getAttribute("data-status"),
      href: new URL(el.querySelector(adapter.reconcile.href)?.getAttribute("href") || "", location.href).href
    }));
    panel.status(`Read ${items.length} listings`);
    await ask({ type: "RECONCILE_RESULT", items });
  }
  (async () => {
    if (!MARKET) return;
    if (parseListingUrl(MARKET, location.href)) {
      await ask({ type: "LISTING_SEEN", url: location.href }).catch(() => {
      });
      return;
    }
    const job = await getJob();
    if (!job) return;
    if (job.kind === "fill") return runFill(job);
    if (job.kind === "reconcile") return runReconcile(job);
  })();
})();
