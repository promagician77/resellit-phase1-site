// extension/src/adapters/poshmark.json
var poshmark_default = {
  market: "poshmark",
  version: "1.0.0",
  note: "Data only (labels and selectors), no code: ReSellit can ship an update to this file without a new extension build. Live-site labels are from Poshmark's listing fields; selectors are calibrated on a signed-in Poshmark account in week 1 (no listing is published during calibration).",
  targets: {
    live: { createUrl: "https://poshmark.com/create-listing", listingPrefix: "https://poshmark.com/listing/" },
    double: { createUrl: "/market/poshmark/create-listing/", listingPrefix: "/market/poshmark/listing/", closetUrl: "/market/poshmark/closet/" }
  },
  ready: { key: "ready", kind: "text", label: ["Title"], selectors: ["[data-testid=title]"] },
  never: ["[data-testid=list-button]", "[data-testid=next-button]", "button[type=submit]"],
  fields: [
    { key: "photos", from: "photos", kind: "files", label: ["Photos", "Add photos"], selectors: ["[data-testid=photo-input]"], countSelector: "[data-photo-name]", required: true },
    { key: "title", from: "title", kind: "text", label: ["Title", "Listing title"], selectors: ["[data-testid=title]"], required: true },
    { key: "description", from: "description", kind: "textarea", label: ["Description"], selectors: ["[data-testid=description]"], required: true },
    { key: "category", from: "category", kind: "path", label: ["Category"], selectors: ["[data-testid=category]"], required: true },
    { key: "size", from: "size", kind: "select", label: ["Size"], selectors: ["[data-testid=size]"], required: true },
    { key: "brand", from: "brand", kind: "combo", label: ["Brand"], selectors: ["[data-testid=brand]"] },
    { key: "nwt", from: "nwt", kind: "toggle", label: ["New With Tags", "New With Tags (NWT)", "NWT"], selectors: ["[data-testid=nwt]"] },
    { key: "colors", from: "colors", kind: "chips", label: ["Color", "Colors"], selectors: ["[data-testid=colors]"], max: 2 },
    { key: "originalPrice", from: "originalPrice", kind: "text", label: ["Original Price"], selectors: ["[data-testid=original-price]"] },
    { key: "price", from: "price", kind: "text", label: ["Listing Price"], selectors: ["[data-testid=listing-price]"], required: true },
    { key: "sku", from: "sku", kind: "text", label: ["SKU"], selectors: ["[data-testid=sku]"], required: true },
    { key: "notes", from: "notes", kind: "textarea", label: ["Other Info", "Private notes"], selectors: ["[data-testid=other-info]"] }
  ],
  reconcile: { item: "[data-listing-id]", sku: "data-sku", id: "data-listing-id", href: "a[href*='/listing/']" }
};

// extension/src/adapters/mercari.json
var mercari_default = {
  market: "mercari",
  version: "1.0.0",
  note: "Full-version adapter, calibrated against the test double. The live-site adapter is built and calibrated in the phase that adds this marketplace.",
  targets: {
    live: null,
    double: {
      createUrl: "/market/mercari/create-listing/",
      closetUrl: "/market/mercari/closet/"
    }
  },
  ready: {
    key: "ready",
    kind: "text",
    label: [
      "Title"
    ]
  },
  never: [
    "button[type=submit]"
  ],
  fields: [
    {
      key: "photos",
      from: "photos",
      kind: "files",
      label: [
        "Photos"
      ],
      countSelector: "[data-photo-name]",
      required: true
    },
    {
      key: "title",
      from: "title",
      kind: "text",
      label: [
        "Title"
      ],
      required: true
    },
    {
      key: "description",
      from: "description",
      kind: "textarea",
      label: [
        "Description"
      ],
      required: true
    },
    {
      key: "category",
      from: "category",
      kind: "path",
      label: [
        "Category"
      ],
      required: true
    },
    {
      key: "brand",
      from: "brand",
      kind: "combo",
      label: [
        "Brand"
      ]
    },
    {
      key: "condition",
      from: "condition",
      kind: "select",
      label: [
        "Condition"
      ],
      required: true
    },
    {
      key: "size",
      from: "size",
      kind: "select",
      label: [
        "Size"
      ]
    },
    {
      key: "color",
      from: "color",
      kind: "select",
      label: [
        "Color"
      ]
    },
    {
      key: "price",
      from: "price",
      kind: "text",
      label: [
        "Price"
      ],
      required: true
    }
  ],
  reconcile: {
    item: "[data-listing-id]",
    sku: "data-sku",
    id: "data-listing-id",
    href: "a"
  }
};

// extension/src/adapters/depop.json
var depop_default = {
  market: "depop",
  version: "1.0.0",
  note: "Full-version adapter, calibrated against the test double. The live-site adapter is built and calibrated in the phase that adds this marketplace.",
  targets: {
    live: null,
    double: {
      createUrl: "/market/depop/create-listing/",
      closetUrl: "/market/depop/closet/"
    }
  },
  ready: {
    key: "ready",
    kind: "textarea",
    label: [
      "Description"
    ]
  },
  never: [
    "button[type=submit]"
  ],
  fields: [
    {
      key: "photos",
      from: "photos",
      kind: "files",
      label: [
        "Photos"
      ],
      countSelector: "[data-photo-name]",
      required: true
    },
    {
      key: "description",
      from: "description",
      kind: "textarea",
      label: [
        "Description"
      ],
      required: true
    },
    {
      key: "category",
      from: "category",
      kind: "path",
      label: [
        "Category"
      ],
      required: true
    },
    {
      key: "brand",
      from: "brand",
      kind: "combo",
      label: [
        "Brand"
      ]
    },
    {
      key: "condition",
      from: "condition",
      kind: "select",
      label: [
        "Condition"
      ],
      required: true
    },
    {
      key: "size",
      from: "size",
      kind: "select",
      label: [
        "Size"
      ]
    },
    {
      key: "colors",
      from: "colors",
      kind: "chips",
      label: [
        "Colour",
        "Color"
      ],
      max: 2
    },
    {
      key: "sku",
      from: "sku",
      kind: "text",
      label: [
        "SKU"
      ]
    },
    {
      key: "price",
      from: "price",
      kind: "text",
      label: [
        "Item price",
        "Price"
      ],
      required: true
    }
  ],
  reconcile: {
    item: "[data-listing-id]",
    sku: "data-sku",
    id: "data-listing-id",
    href: "a"
  }
};

// extension/src/adapters/vinted.json
var vinted_default = {
  market: "vinted",
  version: "1.0.0",
  note: "Full-version adapter, calibrated against the test double. The live-site adapter is built and calibrated in the phase that adds this marketplace.",
  targets: {
    live: null,
    double: {
      createUrl: "/market/vinted/create-listing/",
      closetUrl: "/market/vinted/closet/"
    }
  },
  ready: {
    key: "ready",
    kind: "text",
    label: [
      "Title"
    ]
  },
  never: [
    "button[type=submit]"
  ],
  fields: [
    {
      key: "photos",
      from: "photos",
      kind: "files",
      label: [
        "Upload photos",
        "Photos"
      ],
      countSelector: "[data-photo-name]",
      required: true
    },
    {
      key: "title",
      from: "title",
      kind: "text",
      label: [
        "Title"
      ],
      required: true
    },
    {
      key: "description",
      from: "description",
      kind: "textarea",
      label: [
        "Describe your item",
        "Description"
      ],
      required: true
    },
    {
      key: "category",
      from: "category",
      kind: "path",
      label: [
        "Category"
      ],
      required: true
    },
    {
      key: "brand",
      from: "brand",
      kind: "combo",
      label: [
        "Brand"
      ]
    },
    {
      key: "size",
      from: "size",
      kind: "select",
      label: [
        "Size"
      ]
    },
    {
      key: "condition",
      from: "condition",
      kind: "select",
      label: [
        "Condition"
      ],
      required: true
    },
    {
      key: "colors",
      from: "colors",
      kind: "chips",
      label: [
        "Colour",
        "Color"
      ],
      max: 2
    },
    {
      key: "price",
      from: "price",
      kind: "text",
      label: [
        "Price"
      ],
      required: true
    }
  ],
  reconcile: {
    item: "[data-listing-id]",
    sku: "data-sku",
    id: "data-listing-id",
    href: "a"
  }
};

// extension/src/adapters/facebook.json
var facebook_default = {
  market: "facebook",
  version: "1.0.0",
  note: "Full-version adapter, calibrated against the test double. The live-site adapter is built and calibrated in the phase that adds this marketplace.",
  targets: {
    live: null,
    double: {
      createUrl: "/market/facebook/create-listing/",
      closetUrl: "/market/facebook/closet/"
    }
  },
  ready: {
    key: "ready",
    kind: "text",
    label: [
      "Title"
    ]
  },
  never: [
    "button[type=submit]"
  ],
  fields: [
    {
      key: "photos",
      from: "photos",
      kind: "files",
      label: [
        "Add photos",
        "Photos"
      ],
      countSelector: "[data-photo-name]",
      required: true
    },
    {
      key: "title",
      from: "title",
      kind: "text",
      label: [
        "Title"
      ],
      required: true
    },
    {
      key: "price",
      from: "price",
      kind: "text",
      label: [
        "Price"
      ],
      required: true
    },
    {
      key: "category",
      from: "category",
      kind: "path",
      label: [
        "Category"
      ],
      required: true
    },
    {
      key: "condition",
      from: "condition",
      kind: "select",
      label: [
        "Condition"
      ],
      required: true
    },
    {
      key: "description",
      from: "description",
      kind: "textarea",
      label: [
        "Description"
      ]
    }
  ],
  reconcile: {
    item: "[data-listing-id]",
    sku: "data-sku",
    id: "data-listing-id",
    href: "a"
  }
};

// extension/src/lib/transfer.js
var OPEN_OK = /* @__PURE__ */ new Set([void 0, null, "none", "abandoned", "failed"]);
var transferKey = (resellitId, market) => `${resellitId}::${market}`;
function decide(record, { tabAlive: tabAlive2 = false } = {}) {
  const st = record?.state;
  if (OPEN_OK.has(st)) return { action: "open" };
  if (st === "published") return { action: "blocked", reason: "already_listed", url: record.url, listingId: record.listingId };
  if (st === "filling" || st === "review") {
    return tabAlive2 ? { action: "focus", tabId: record.tabId } : { action: "check", reason: "tab_gone" };
  }
  if (st === "needs_check") return { action: "check", reason: "unconfirmed" };
  if (st === "sold" || st === "delisted") return { action: "blocked", reason: st, url: record.url };
  return { action: "check", reason: "unknown_state" };
}
var now = () => (/* @__PURE__ */ new Date()).toISOString();
function reduce(record, event) {
  const r = record ? { ...record, log: [...record.log || []] } : { state: "none", log: [] };
  const log = (msg, extra) => r.log.push({ at: event.at || now(), event: event.type, msg, ...extra || {} });
  switch (event.type) {
    case "OPEN":
      if (!OPEN_OK.has(record?.state)) throw new Error(`OPEN refused in state ${record?.state}`);
      Object.assign(r, { state: "filling", tabId: event.tabId, fingerprint: event.fingerprint, sku: event.sku || r.sku || null, attempt: (r.attempt || 0) + 1, url: null, listingId: null, report: null });
      log(`Opened ${event.marketName || "marketplace"} form (attempt ${r.attempt})`);
      break;
    case "FILLED": {
      if (r.state !== "filling") return r;
      const rep = event.report || {};
      r.report = rep;
      r.state = "review";
      log(`Filled ${rep.filled ?? "?"} of ${rep.total ?? "?"} fields${rep.missing?.length ? "; needs attention: " + rep.missing.join(", ") : ""}. Waiting for the seller to review and list.`);
      break;
    }
    case "PUBLISHED":
      if (r.state === "published" && r.listingId === event.listingId) return r;
      Object.assign(r, { state: "published", url: event.url, listingId: event.listingId, publishedAt: event.at || now(), tabId: null });
      log(`Listed. Link captured: ${event.url}`);
      break;
    case "TAB_CLOSED":
      if (r.state === "filling" || r.state === "review") {
        r.state = "needs_check";
        r.tabId = null;
        log("Tab closed before a listing link was captured. Checking the marketplace before allowing another send.");
      }
      break;
    case "RECONCILED":
      if (r.state !== "needs_check") return r;
      if (event.found) {
        Object.assign(r, { state: "published", url: event.url, listingId: event.listingId, publishedAt: event.at || now() });
        log(`Found the listing by SKU ${event.sku}: ${event.url}. No duplicate created.`);
      } else {
        r.state = "abandoned";
        log(`No listing with SKU ${event.sku} on the marketplace. Safe to send again.`);
      }
      break;
    case "FAILED":
      r.state = "failed";
      r.tabId = null;
      log(`Failed: ${event.error}`);
      break;
    case "SOLD":
      Object.assign(r, { state: "sold", soldAt: event.at || now(), soldPrice: event.price });
      log(`Sold${event.price ? " for $" + event.price : ""}.`);
      break;
    case "DELISTED":
      Object.assign(r, { state: "delisted", delistedAt: event.at || now() });
      log("Removed from the marketplace.");
      break;
    default:
      throw new Error(`Unknown event ${event.type}`);
  }
  return r;
}

// extension/src/lib/markets.js
var MARKETS = {
  poshmark: {
    name: "Poshmark",
    route: "browser",
    officialApi: "No public listing API. Bulk Upload (CSV) exists for Posh Ambassadors and Brand Partners only.",
    titleMax: 80,
    descMax: 1500,
    photosMax: 16,
    wholeDollars: true,
    hasTitle: true,
    skuField: true,
    privateNotesMax: 500,
    saleSignal: "No sale notifications to third parties: check the seller\u2019s sold items while the browser is open.",
    delist: "Delete the listing or set Availability to Not For Sale.",
    conditions: { new_with_tags: "NWT", new_without_tags: "", like_new: "", good: "", fair: "" },
    sources: {
      titleMax: "Poshmark Support, Bulk Upload Templates: Title 80 character limit",
      descMax: "Poshmark Support, Bulk Upload Templates: Description 1500 character limit",
      photosMax: "Nifty and Spadeberry seller guides: up to 16 photos",
      wholeDollars: "Poshmark Support, Bulk Upload Templates: round pricing to whole amounts",
      privateNotesMax: "Poshmark Support: Other Info 500 characters, visible only to you"
    }
  },
  ebay: {
    name: "eBay",
    route: "api",
    officialApi: "Sell Inventory API + Media API (OAuth). Listings are created without a browser.",
    titleMax: 80,
    descMax: null,
    photosMax: 24,
    wholeDollars: false,
    hasTitle: true,
    skuField: true,
    saleSignal: "Notification API (ORDER_CONFIRMATION) needs a public HTTPS endpoint; a local ReSellit polls Fulfillment getOrders instead.",
    delist: "Withdraw the offer through the Inventory API.",
    conditions: { new_with_tags: "NEW", new_without_tags: "NEW_OTHER", like_new: "USED_EXCELLENT", good: "USED_GOOD", fair: "USED_ACCEPTABLE" },
    sources: {
      titleMax: "eBay seller guidance: 80-character title",
      photosMax: "Spadeberry eBay guide: up to 24 photos"
    }
  },
  mercari: {
    name: "Mercari",
    route: "browser",
    officialApi: "No public seller API.",
    titleMax: 80,
    descMax: 1e3,
    photosMax: 12,
    wholeDollars: false,
    hasTitle: true,
    skuField: false,
    saleSignal: "Check sold items while the browser is open.",
    delist: "Deactivate or delete the listing.",
    conditions: { new_with_tags: "New", new_without_tags: "Like new", like_new: "Like new", good: "Good", fair: "Fair" },
    sources: {
      titleMax: "Mercari blog: 80 characters",
      descMax: "Mercari blog: 1,000 characters",
      photosMax: "Mercari Help Center: up to 12 photos"
    }
  },
  depop: {
    name: "Depop",
    route: "browser",
    officialApi: "Selling API for approved partners (partner-gated); browser route otherwise.",
    titleMax: null,
    descMax: 1e3,
    photosMax: 8,
    wholeDollars: false,
    hasTitle: false,
    skuField: true,
    skuMax: 50,
    saleSignal: "Partner API sends webhooks; browser route checks sold items.",
    delist: "Delete the listing.",
    conditions: { new_with_tags: "Brand new", new_without_tags: "Like new", like_new: "Like new", good: "Used - Good", fair: "Used - Fair" },
    sources: {
      hasTitle: "Spadeberry and Closo: Depop has no title field; title goes at the top of the description",
      descMax: "Spadeberry Depop guide: 1,000 characters",
      photosMax: "Spadeberry Depop guide: up to 8 photos",
      skuMax: "Spadeberry Depop guide: SKU capped at 50 characters"
    }
  },
  vinted: {
    name: "Vinted",
    route: "browser",
    officialApi: "Vinted Pro Integrations: allowlisted Pro businesses only, 4\u20136 week setup.",
    titleMax: null,
    descMax: null,
    photosMax: 20,
    wholeDollars: false,
    hasTitle: true,
    skuField: false,
    noIdenticalItems: true,
    saleSignal: "Check sold items while the browser is open.",
    delist: "Delete the listing.",
    conditions: { new_with_tags: "New with tags", new_without_tags: "New without tags", like_new: "Very good", good: "Good", fair: "Satisfactory" },
    sources: {
      photosMax: "Vinted Help Centre: up to 20 photos",
      noIdenticalItems: "Vinted Help Centre: identical items can\u2019t be listed twice"
    }
  },
  facebook: {
    name: "Facebook Marketplace",
    route: "browser",
    officialApi: "No public Marketplace API for individual sellers (partner catalog APIs only).",
    titleMax: null,
    descMax: null,
    photosMax: 10,
    wholeDollars: false,
    hasTitle: true,
    skuField: false,
    saleSignal: "No sold signal for most sales (local pickup); the seller marks it sold.",
    delist: "Mark as sold or delete.",
    conditions: { new_with_tags: "New", new_without_tags: "New", like_new: "Used - Like New", good: "Used - Good", fair: "Used - Fair" },
    sources: {
      photosMax: "Seller guides (not an official Meta page): up to 10 photos"
    }
  }
};
var MARKET_KEYS = Object.keys(MARKETS);

// extension/src/lib/mapping.js
var clean = (s) => String(s ?? "").replace(/\r\n?/g, "\n").replace(/[ \t]+\n/g, "\n").trim();
function truncateWords(text, max) {
  if (!max || text.length <= max) return text;
  const cut = text.slice(0, max + 1);
  const at = cut.lastIndexOf(" ");
  return (at > max * 0.6 ? cut.slice(0, at) : text.slice(0, max)).replace(/[\s,;:\-–]+$/, "");
}
function truncateText(text, max) {
  if (!max || text.length <= max) return text;
  return truncateWords(text, max - 1) + "\u2026";
}
function toMarketPayload(draft, marketKey) {
  const m = MARKETS[marketKey];
  if (!m) throw new Error(`Unknown marketplace: ${marketKey}`);
  const warnings = [];
  const errors = [];
  let title = clean(draft.title).replace(/\s+/g, " ");
  let description = clean(draft.description);
  if (!title) errors.push({ field: "title", msg: "Title is empty" });
  if (!description) errors.push({ field: "description", msg: "Description is empty" });
  if (!m.hasTitle) {
    description = title + (description ? "\n\n" + description : "");
    warnings.push({ field: "title", msg: `${m.name} has no title field: title placed at the top of the description` });
    title = null;
  } else if (m.titleMax && title.length > m.titleMax) {
    const t = truncateWords(title, m.titleMax);
    warnings.push({ field: "title", msg: `Title shortened from ${title.length} to ${t.length} characters (limit ${m.titleMax})` });
    title = t;
  }
  if (m.descMax && description.length > m.descMax) {
    const d = truncateText(description, m.descMax);
    warnings.push({ field: "description", msg: `Description shortened from ${description.length} to ${d.length} characters (limit ${m.descMax})` });
    description = d;
  }
  const photos = (draft.photos || []).slice();
  if (!photos.length) errors.push({ field: "photos", msg: "At least one photo is required" });
  if (m.photosMax && photos.length > m.photosMax) {
    warnings.push({ field: "photos", msg: `${photos.length} photos; ${m.name} takes ${m.photosMax}, so the last ${photos.length - m.photosMax} are left out` });
    photos.length = m.photosMax;
  }
  let price = Number(draft.price);
  if (!(price > 0)) errors.push({ field: "price", msg: "Price must be greater than 0" });
  if (m.wholeDollars && price % 1 !== 0) {
    const p = Math.ceil(price);
    warnings.push({ field: "price", msg: `${m.name} takes whole dollars: $${price.toFixed(2)} rounded up to $${p}` });
    price = p;
  }
  let originalPrice = draft.originalPrice == null ? null : Number(draft.originalPrice);
  if (originalPrice != null && m.wholeDollars && originalPrice % 1 !== 0) originalPrice = Math.ceil(originalPrice);
  const sku = String(draft.sku || draft.id || "").trim();
  if (m.skuField && !sku) errors.push({ field: "sku", msg: "A SKU is needed to find the listing again" });
  if (m.skuMax && sku.length > m.skuMax) errors.push({ field: "sku", msg: `SKU longer than ${m.skuMax} characters` });
  const condition = m.conditions[draft.condition] ?? "";
  const payload = {
    market: marketKey,
    resellitId: draft.id,
    title,
    description,
    photos,
    price,
    originalPrice,
    brand: draft.brand || "",
    category: draft.category || [],
    size: draft.size || "",
    colors: (draft.colors || []).slice(0, 2),
    color: (draft.colors || [])[0] || "",
    condition,
    nwt: draft.condition === "new_with_tags",
    sku: m.skuField ? sku : null,
    // Private note (Poshmark "Other Info" is visible only to the seller): a second, human-readable link back.
    notes: m.privateNotesMax ? truncateText(`ReSellit ${draft.id}${draft.bin ? " \xB7 bin " + draft.bin : ""}`, m.privateNotesMax) : null
  };
  return { payload, warnings, errors, ok: errors.length === 0 };
}
function draftFingerprint(draft) {
  const s = JSON.stringify([draft.title, draft.description, draft.price, draft.brand, draft.size, (draft.photos || []).map((p) => p.url || p.name)]);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

// extension/src/lib/listing-id.js
var PATTERNS = {
  poshmark: /\/listing\/(?:[^/?#]*-)?([0-9a-f]{24})(?=[/?#]|$)/i,
  ebay: /\/itm\/(?:[^/?#]*\/)?(\d{9,15})(?=[/?#]|$)/,
  mercari: /\/item\/(m\d{6,15})(?=[/?#]|$)/i,
  depop: /\/products\/([a-z0-9][a-z0-9-]{2,120})(?=\/?[?#]?|$)/i,
  vinted: /\/items\/(\d{5,15})(?:-[^/?#]*)?(?=[/?#]|$)/,
  facebook: /\/marketplace\/item\/(\d{6,20})(?=[/?#]|$)/
};
function parseListingUrl(market, href) {
  let u;
  try {
    u = new URL(href);
  } catch {
    return null;
  }
  const re = PATTERNS[market];
  if (!re) return null;
  const m = u.pathname.match(re);
  if (!m) return null;
  return { market, listingId: m[1], url: u.origin + u.pathname };
}

// extension/src/lib/adapter.js
var FIELD_KEYS = /* @__PURE__ */ new Set(["key", "from", "kind", "label", "selectors", "required", "max", "countSelector", "writeFalse"]);
var KINDS = /* @__PURE__ */ new Set(["text", "textarea", "files", "select", "path", "combo", "toggle", "chips"]);
var isStrArr = (a) => Array.isArray(a) && a.every((s) => typeof s === "string" && s.length < 200);
function validateAdapter(a) {
  const errs = [];
  if (!a || typeof a !== "object") return ["not an object"];
  if (typeof a.market !== "string") errs.push("market missing");
  if (!/^\d+\.\d+\.\d+$/.test(a.version || "")) errs.push("version must be x.y.z");
  if (!Array.isArray(a.fields) || !a.fields.length) errs.push("fields missing");
  for (const f of a.fields || []) {
    for (const k of Object.keys(f)) if (!FIELD_KEYS.has(k)) errs.push(`${f.key}: unknown key ${k}`);
    if (!KINDS.has(f.kind)) errs.push(`${f.key}: bad kind ${f.kind}`);
    if (!isStrArr(f.label)) errs.push(`${f.key}: label must be a list of strings`);
    if (f.selectors && !isStrArr(f.selectors)) errs.push(`${f.key}: selectors must be a list of strings`);
  }
  return errs;
}
function applyPatch(adapter, patch) {
  if (patch.market !== adapter.market) throw new Error("patch is for another marketplace");
  const out = JSON.parse(JSON.stringify(adapter));
  out.version = patch.version;
  for (const [k, labels] of Object.entries(patch.addLabels || {})) {
    const f = out.fields.find((x) => x.key === k);
    if (!f || !isStrArr(labels)) throw new Error(`bad patch for ${k}`);
    f.label = [.../* @__PURE__ */ new Set([...f.label, ...labels])];
  }
  for (const [k, sels] of Object.entries(patch.addSelectors || {})) {
    const f = out.fields.find((x) => x.key === k);
    if (!f || !isStrArr(sels)) throw new Error(`bad patch for ${k}`);
    f.selectors = [.../* @__PURE__ */ new Set([...f.selectors || [], ...sels])];
  }
  const errs = validateAdapter(out);
  if (errs.length) throw new Error("patched adapter invalid: " + errs.join("; "));
  return out;
}

// extension/src/background.js
var BUILTIN = { poshmark: poshmark_default, mercari: mercari_default, depop: depop_default, vinted: vinted_default, facebook: facebook_default };
var ports = /* @__PURE__ */ new Set();
var lock = Promise.resolve();
var serial = (fn) => lock = lock.then(fn, fn);
var getTransfers = async () => (await chrome.storage.local.get("transfers")).transfers || {};
var putTransfer = async (key, rec) => {
  const t = await getTransfers();
  t[key] = rec;
  await chrome.storage.local.set({ transfers: t });
  return rec;
};
var jobKey = (tabId) => `job:${tabId}`;
async function adapterFor(market) {
  const { adapterPatches = {} } = await chrome.storage.local.get("adapterPatches");
  let a = BUILTIN[market];
  for (const p of adapterPatches[market] || []) a = applyPatch(a, p);
  return a;
}
async function notify(key, record) {
  const { outbox = [] } = await chrome.storage.local.get("outbox");
  const msg = { type: "RECORD_UPDATE", msgId: crypto.randomUUID(), key, record: strip(record) };
  outbox.push(msg);
  await chrome.storage.local.set({ outbox });
  for (const p of ports) try {
    p.postMessage(msg);
  } catch {
  }
}
async function flush(port) {
  const { outbox = [] } = await chrome.storage.local.get("outbox");
  for (const m of outbox) try {
    port.postMessage(m);
  } catch {
  }
}
async function ack(msgId) {
  const { outbox = [] } = await chrome.storage.local.get("outbox");
  await chrome.storage.local.set({ outbox: outbox.filter((m) => m.msgId !== msgId) });
}
var strip = (r) => ({ ...r, log: (r.log || []).slice(-30) });
async function apply(key, event) {
  const rec = reduce((await getTransfers())[key], event);
  await putTransfer(key, rec);
  await notify(key, rec);
  return rec;
}
async function tabAlive(id) {
  if (!id) return false;
  try {
    await chrome.tabs.get(id);
    return true;
  } catch {
    return false;
  }
}
async function send({ draft, market = "poshmark", target = "live", origin, variant }) {
  return serial(async () => {
    const key = transferKey(draft.id, market);
    const rec = (await getTransfers())[key];
    const d = decide(rec, { tabAlive: await tabAlive(rec?.tabId) });
    if (d.action === "focus") {
      const tab2 = await chrome.tabs.update(d.tabId, { active: true });
      await chrome.windows.update(tab2.windowId, { focused: true });
      return { action: "focused", record: strip(rec) };
    }
    if (d.action === "blocked") return { action: "blocked", reason: d.reason, record: strip(rec) };
    if (d.action === "check") {
      if (rec.state !== "needs_check") await apply(key, { type: "TAB_CLOSED" });
      return { action: "check", reason: d.reason, record: strip((await getTransfers())[key]) };
    }
    const mapped = toMarketPayload(draft, market);
    if (!mapped.ok) return { action: "invalid", errors: mapped.errors, warnings: mapped.warnings };
    const adapter = await adapterFor(market);
    const t = target === "live" ? adapter.targets.live : adapter.targets.double;
    if (!t) return { action: "invalid", errors: [{ field: "market", msg: `${MARKETS[market].name} live adapter is not built yet` }] };
    const url = new URL(t.createUrl, origin || void 0);
    if (variant) url.searchParams.set("variant", variant);
    const photos = mapped.payload.photos.map((p) => new URL(p.url, origin || void 0).href);
    const tab = await chrome.tabs.create({ url: url.href, active: true });
    await chrome.storage.session.set({ [jobKey(tab.id)]: { kind: "fill", key, market, payload: { ...mapped.payload, photos: void 0 }, photos, warnings: mapped.warnings } });
    const r = await apply(key, { type: "OPEN", tabId: tab.id, fingerprint: draftFingerprint(draft), sku: mapped.payload.sku || draft.id, marketName: MARKETS[market].name });
    return { action: "opened", record: strip(r), warnings: mapped.warnings };
  });
}
async function check({ resellitId, market = "poshmark", target = "live", origin }) {
  const key = transferKey(resellitId, market);
  const rec = (await getTransfers())[key];
  if (!rec || rec.state !== "needs_check") return { action: "noop", record: rec && strip(rec) };
  const adapter = await adapterFor(market);
  const t = target === "live" ? adapter.targets.live : adapter.targets.double;
  if (!t?.closetUrl) return { action: "manual", record: strip(rec), msg: "Open your closet, find the item and paste its link into ReSellit." };
  const tab = await chrome.tabs.create({ url: new URL(t.closetUrl, origin || void 0).href, active: false });
  await chrome.storage.session.set({ [jobKey(tab.id)]: { kind: "reconcile", key, market, sku: rec.sku || resellitId } });
  return { action: "checking", record: strip(rec) };
}
async function linkManually({ resellitId, market = "poshmark", url }) {
  const parsed = parseListingUrl(market, url);
  if (!parsed) return { action: "invalid", errors: [{ field: "url", msg: "That is not a listing link for " + MARKETS[market].name }] };
  const key = transferKey(resellitId, market);
  const rec = (await getTransfers())[key];
  const r = rec?.state === "needs_check" ? await apply(key, { type: "RECONCILED", found: true, url: parsed.url, listingId: parsed.listingId, sku: resellitId }) : await apply(key, { type: "PUBLISHED", url: parsed.url, listingId: parsed.listingId });
  return { action: "linked", record: strip(r) };
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "resellit") return;
  ports.add(port);
  port.onDisconnect.addListener(() => ports.delete(port));
  port.onMessage.addListener(async (msg) => {
    const reply = (data) => port.postMessage({ type: msg.type + "_RESULT", reqId: msg.reqId, ...data });
    try {
      if (msg.type === "HELLO") {
        reply({ version: chrome.runtime.getManifest().version, markets: Object.keys(BUILTIN) });
        flush(port);
      } else if (msg.type === "SEND") reply(await send(msg));
      else if (msg.type === "CHECK") reply(await check(msg));
      else if (msg.type === "LINK") reply(await linkManually(msg));
      else if (msg.type === "RECORDS") reply({ records: Object.fromEntries(Object.entries(await getTransfers()).map(([k, v]) => [k, strip(v)])) });
      else if (msg.type === "ACK") await ack(msg.msgId);
      else if (msg.type === "RESET") {
        await chrome.storage.local.remove(["transfers", "outbox"]);
        reply({ ok: true });
      } else if (msg.type === "PATCH_ADAPTER") {
        const base = await adapterFor(msg.patch.market);
        applyPatch(base, msg.patch);
        const { adapterPatches = {} } = await chrome.storage.local.get("adapterPatches");
        (adapterPatches[msg.patch.market] ||= []).push(msg.patch);
        await chrome.storage.local.set({ adapterPatches });
        reply({ ok: true, version: msg.patch.version });
      }
    } catch (e) {
      reply({ action: "error", error: e.message });
    }
  });
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  (async () => {
    if (msg.type === "GET_JOB") {
      const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)] || null;
      if (!job) return null;
      return { ...job, adapter: await adapterFor(job.market) };
    }
    if (msg.type === "GET_PHOTO") {
      const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
      const url = job?.photos?.[msg.index];
      if (!url) return null;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error(`photo ${msg.index + 1}: HTTP ${res.status}`);
      const buf = new Uint8Array(await res.arrayBuffer());
      let bin = "";
      for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 32768));
      return { name: url.split("/").slice(-2).join("-"), type: res.headers.get("content-type") || "image/jpeg", b64: btoa(bin) };
    }
    if (msg.type === "FILLED") {
      const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
      if (job) await apply(job.key, { type: "FILLED", report: msg.report });
      return true;
    }
    if (msg.type === "FILL_FAILED") {
      const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
      if (job) await apply(job.key, { type: "FAILED", error: msg.error });
      return true;
    }
    if (msg.type === "LISTING_SEEN") return capture(tabId, msg.url);
    if (msg.type === "RECONCILE_RESULT") {
      const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
      if (!job) return false;
      const hit = msg.items.find((i) => i.sku === job.sku && i.status !== "deleted");
      const parsed = hit && parseListingUrl(job.market, hit.href);
      await apply(job.key, hit ? { type: "RECONCILED", found: true, url: parsed?.url || hit.href, listingId: parsed?.listingId || hit.id, sku: job.sku } : { type: "RECONCILED", found: false, sku: job.sku });
      await chrome.storage.session.remove(jobKey(tabId));
      chrome.tabs.remove(tabId).catch(() => {
      });
      return true;
    }
    return null;
  })().then(sendResponse, (e) => sendResponse({ error: e.message }));
  return true;
});
async function capture(tabId, url) {
  const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
  if (!job || job.kind !== "fill") return false;
  const parsed = parseListingUrl(job.market, url);
  if (!parsed) return false;
  const rec = (await getTransfers())[job.key];
  if (rec?.state === "published" && rec.listingId === parsed.listingId) return true;
  await apply(job.key, { type: "PUBLISHED", url: parsed.url, listingId: parsed.listingId });
  await chrome.storage.session.remove(jobKey(tabId));
  return true;
}
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.url) capture(tabId, change.url).catch(() => {
  });
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const job = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
  if (!job || job.kind !== "fill") return;
  await chrome.storage.session.remove(jobKey(tabId));
  const rec = (await getTransfers())[job.key];
  if (rec && (rec.state === "filling" || rec.state === "review")) await apply(job.key, { type: "TAB_CLOSED" });
});
