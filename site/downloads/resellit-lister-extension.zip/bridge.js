(() => {
  // extension/src/bridge.js
  (() => {
    if (!document.querySelector('meta[name="resellit-lister"]')) return;
    let port;
    const queue = [];
    const connect = () => {
      port = chrome.runtime.connect({ name: "resellit" });
      port.onMessage.addListener((msg) => window.postMessage({ ...msg, source: "resellit-ext" }, location.origin));
      port.onDisconnect.addListener(() => {
        port = null;
        setTimeout(connect, 300);
      });
      while (queue.length) port.postMessage(queue.shift());
    };
    connect();
    window.addEventListener("message", (e) => {
      if (e.source !== window || e.origin !== location.origin || e.data?.source !== "resellit-app") return;
      const { source, ...msg } = e.data;
      if (port) {
        try {
          port.postMessage(msg);
          return;
        } catch {
        }
      }
      queue.push(msg);
    });
    document.documentElement.setAttribute("data-resellit-extension", chrome.runtime.getManifest().version);
  })();
})();
